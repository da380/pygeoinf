#from pygeoinf.S2.spherical_harmonic_space import SphericalHarmonicSpace
#from pygeoinf.s2.l2 import L2
#from pygeoinf.S2.sobolev import Sobolev, Lebesgue

