# pygeoinf


A package for solving inference and inverse problems, with a focus on geophysical applications. Developement is still at an early stage, and this package is not suitable for general use. 